﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txtGoi = New System.Windows.Forms.TextBox()
        Me.txtNhan = New System.Windows.Forms.TextBox()
        Me.txtTieuDe = New System.Windows.Forms.TextBox()
        Me.txtBody = New System.Windows.Forms.TextBox()
        Me.txtSmtp = New System.Windows.Forms.TextBox()
        Me.txtPort = New System.Windows.Forms.TextBox()
        Me.txtLogin = New System.Windows.Forms.TextBox()
        Me.txtPass = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Location = New System.Drawing.Point(12, 346)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(394, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "SEND >>>"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txtGoi
        '
        Me.txtGoi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtGoi.Location = New System.Drawing.Point(12, 12)
        Me.txtGoi.Name = "txtGoi"
        Me.txtGoi.Size = New System.Drawing.Size(394, 20)
        Me.txtGoi.TabIndex = 1
        Me.txtGoi.Text = "Mail Gửi"
        Me.txtGoi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtNhan
        '
        Me.txtNhan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNhan.Location = New System.Drawing.Point(12, 38)
        Me.txtNhan.Name = "txtNhan"
        Me.txtNhan.Size = New System.Drawing.Size(394, 20)
        Me.txtNhan.TabIndex = 2
        Me.txtNhan.Text = "Mail Nhận"
        Me.txtNhan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtTieuDe
        '
        Me.txtTieuDe.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTieuDe.Location = New System.Drawing.Point(12, 64)
        Me.txtTieuDe.Name = "txtTieuDe"
        Me.txtTieuDe.Size = New System.Drawing.Size(394, 20)
        Me.txtTieuDe.TabIndex = 3
        Me.txtTieuDe.Text = "Tiêu Đề"
        Me.txtTieuDe.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtBody
        '
        Me.txtBody.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtBody.Location = New System.Drawing.Point(12, 90)
        Me.txtBody.Multiline = True
        Me.txtBody.Name = "txtBody"
        Me.txtBody.Size = New System.Drawing.Size(394, 142)
        Me.txtBody.TabIndex = 4
        Me.txtBody.Text = "Nội Dung"
        Me.txtBody.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtSmtp
        '
        Me.txtSmtp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSmtp.Location = New System.Drawing.Point(12, 238)
        Me.txtSmtp.Name = "txtSmtp"
        Me.txtSmtp.Size = New System.Drawing.Size(394, 20)
        Me.txtSmtp.TabIndex = 5
        Me.txtSmtp.Text = "SMTP"
        Me.txtSmtp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtPort
        '
        Me.txtPort.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPort.Location = New System.Drawing.Point(12, 264)
        Me.txtPort.Name = "txtPort"
        Me.txtPort.Size = New System.Drawing.Size(394, 20)
        Me.txtPort.TabIndex = 6
        Me.txtPort.Text = "PORT"
        Me.txtPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtLogin
        '
        Me.txtLogin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtLogin.Location = New System.Drawing.Point(12, 290)
        Me.txtLogin.Name = "txtLogin"
        Me.txtLogin.Size = New System.Drawing.Size(394, 20)
        Me.txtLogin.TabIndex = 7
        Me.txtLogin.Text = "UserName"
        Me.txtLogin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtPass
        '
        Me.txtPass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPass.Location = New System.Drawing.Point(12, 316)
        Me.txtPass.Name = "txtPass"
        Me.txtPass.Size = New System.Drawing.Size(394, 20)
        Me.txtPass.TabIndex = 8
        Me.txtPass.Text = "PassWord"
        Me.txtPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(418, 381)
        Me.Controls.Add(Me.txtPass)
        Me.Controls.Add(Me.txtLogin)
        Me.Controls.Add(Me.txtPort)
        Me.Controls.Add(Me.txtSmtp)
        Me.Controls.Add(Me.txtBody)
        Me.Controls.Add(Me.txtTieuDe)
        Me.Controls.Add(Me.txtNhan)
        Me.Controls.Add(Me.txtGoi)
        Me.Controls.Add(Me.Button1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents txtGoi As System.Windows.Forms.TextBox
    Friend WithEvents txtNhan As System.Windows.Forms.TextBox
    Friend WithEvents txtTieuDe As System.Windows.Forms.TextBox
    Friend WithEvents txtBody As System.Windows.Forms.TextBox
    Friend WithEvents txtSmtp As System.Windows.Forms.TextBox
    Friend WithEvents txtPort As System.Windows.Forms.TextBox
    Friend WithEvents txtLogin As System.Windows.Forms.TextBox
    Friend WithEvents txtPass As System.Windows.Forms.TextBox

End Class
