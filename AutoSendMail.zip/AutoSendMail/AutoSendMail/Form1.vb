﻿Imports System.Net.Mail
Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Me.Cursor = Cursors.WaitCursor
        Me.Text = "Đang gởi mail ...."
        Dim MyMailMessage As New MailMessage()
        MyMailMessage.From = New MailAddress(txtGoi.Text.ToString)
        MyMailMessage.To.Add(txtNhan.Text.ToString)
        MyMailMessage.Subject = txtTieuDe.Text.ToString
        MyMailMessage.Body = txtBody.Text.ToString
        Dim SMTPServer As New SmtpClient(txtSmtp.Text.ToString.Trim)
        SMTPServer.Port = txtPort.Text
        SMTPServer.Credentials = New System.Net.NetworkCredential(txtLogin.Text.ToString.Trim, txtPass.Text.ToString.Trim)
        SMTPServer.EnableSsl = True
        Try
            SMTPServer.Send(MyMailMessage)
            MessageBox.Show("Đã gởi mail thành công đến " & txtNhan.Text)
            Me.Cursor = Cursors.Arrow
            Me.Text = "Đã gởi xong"
        Catch ex As SmtpException
            MessageBox.Show(ex.Message)
            Me.Cursor = Cursors.Arrow
            Me.Text = "Không gởi được mail"
        End Try
    End Sub
End Class
