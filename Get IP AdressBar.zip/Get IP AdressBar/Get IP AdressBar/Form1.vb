﻿Imports System.Net
Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim hostname As IPHostEntry = Dns.GetHostByName(TextBox1.Text)
        Dim ip As IPAddress() = hostname.AddressList
        TextBox2.Text = ip(0).ToString()

        form2.show()
    End Sub
End Class
