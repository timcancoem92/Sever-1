﻿Imports System.IO
Imports System.Threading


Public Class frmPortal


    Private Sub butQuanLi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butQuanLi.Click
        frmQuanLi.ShowDialog(Me)
    End Sub

    Private Sub butTracNghiem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butTracNghiem.Click
        frmTracNghiem.ShowDialog(Me)
    End Sub

End Class

