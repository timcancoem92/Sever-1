﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPortal
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.butQuanLi = New System.Windows.Forms.Button
        Me.butTracNghiem = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'butQuanLi
        '
        Me.butQuanLi.Location = New System.Drawing.Point(9, 14)
        Me.butQuanLi.Name = "butQuanLi"
        Me.butQuanLi.Size = New System.Drawing.Size(132, 51)
        Me.butQuanLi.TabIndex = 0
        Me.butQuanLi.Text = "Quản lí"
        Me.butQuanLi.UseVisualStyleBackColor = True
        '
        'butTracNghiem
        '
        Me.butTracNghiem.Location = New System.Drawing.Point(9, 71)
        Me.butTracNghiem.Name = "butTracNghiem"
        Me.butTracNghiem.Size = New System.Drawing.Size(132, 54)
        Me.butTracNghiem.TabIndex = 1
        Me.butTracNghiem.Text = "Trắc nghiệm"
        Me.butTracNghiem.UseVisualStyleBackColor = True
        '
        'frmPortal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(151, 138)
        Me.Controls.Add(Me.butTracNghiem)
        Me.Controls.Add(Me.butQuanLi)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmPortal"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Portal"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents butTest As System.Windows.Forms.Button
    Friend WithEvents butQuanLi As System.Windows.Forms.Button
    Friend WithEvents butTracNghiem As System.Windows.Forms.Button

End Class
