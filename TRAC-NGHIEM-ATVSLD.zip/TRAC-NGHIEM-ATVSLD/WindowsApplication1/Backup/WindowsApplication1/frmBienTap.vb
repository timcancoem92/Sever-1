﻿Imports System.IO

Public Class frmBienTap

    Private Sub butTuChoi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butTuChoi.Click
        Me.Close()
    End Sub

    Private Sub butChapNhan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butChapNhan.Click
        '====Kiểm tra===='
        If txt1.Text = "" Or txt2.Text = "" Or txt3.Text = "" Or txt4.Text = "" Or txtCauHoi.Text = "" Then
            MsgBox("Vui lòng nhập đầy đủ thông tin!", MsgBoxStyle.Critical)
            Exit Sub
        End If
        If IsNumeric(Me.Tag) Then
            '====Nếu đang sửa===='
            With frmQuanLi.QuanLi(Me.Tag)
                .Q = txtCauHoi.Text
                .A1 = txt1.Text : .A2 = txt2.Text : .A3 = txt3.Text : .A4 = txt4.Text
                'Ghi dữ liệu
            End With
            Dim Content(frmQuanLi.QuanLi.Length - 1) As String
            For i As Integer = 0 To frmQuanLi.QuanLi.Length - 1
                With frmQuanLi.QuanLi(i)
                    Content(i) = .Q & "/" & .A1 & "/" & .A2 & "/" & .A3 & "/" & .A4 & "/" & .A
                End With
            Next
            File.WriteAllText("Data.ini", Join(Content, vbNewLine))
        Else
            '====Nếu ghi thêm===='
            Dim Content As String = File.ReadAllText("Data.ini")
            Content += vbNewLine & txtCauHoi.Text & "/" & txt1.Text & "/" & _
                txt2.Text & "/" & txt3.Text & "/" & txt4.Text & "/" & cboDapAn.SelectedIndex
            File.WriteAllText("Data.ini", Content)
        End If
        '====Đóng form===='
        Me.Close()
    End Sub

    Private Sub frmBienTap_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If IsNumeric(Me.Tag) Then
            With frmQuanLi.QuanLi(Me.Tag)
                txtCauHoi.Text = .Q
                txt1.Text = .A1
                txt2.Text = .A2
                txt3.Text = .A3
                txt4.Text = .A4
                cboDapAn.SelectedIndex = .A
            End With
        Else
            cboDapAn.SelectedIndex = 0
        End If
    End Sub

End Class