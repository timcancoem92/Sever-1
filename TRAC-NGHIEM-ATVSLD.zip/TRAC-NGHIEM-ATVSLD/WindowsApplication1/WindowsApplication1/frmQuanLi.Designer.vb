﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmQuanLi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.txtTraLoi = New System.Windows.Forms.TextBox()
        Me.txtNoiDung = New System.Windows.Forms.TextBox()
        Me.lstList = New System.Windows.Forms.ListBox()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.butXoa = New System.Windows.Forms.Button()
        Me.butSua = New System.Windows.Forms.Button()
        Me.butThem = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel2, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.lstList, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel3, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88.61386!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.38614!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(531, 404)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 1
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.txtTraLoi, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.txtNoiDung, 0, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(268, 3)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 2
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 93.41177!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.588235!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(260, 351)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'txtTraLoi
        '
        Me.txtTraLoi.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtTraLoi.Location = New System.Drawing.Point(3, 330)
        Me.txtTraLoi.Name = "txtTraLoi"
        Me.txtTraLoi.ReadOnly = True
        Me.txtTraLoi.Size = New System.Drawing.Size(254, 20)
        Me.txtTraLoi.TabIndex = 1
        '
        'txtNoiDung
        '
        Me.txtNoiDung.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtNoiDung.Location = New System.Drawing.Point(3, 3)
        Me.txtNoiDung.Multiline = True
        Me.txtNoiDung.Name = "txtNoiDung"
        Me.txtNoiDung.ReadOnly = True
        Me.txtNoiDung.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtNoiDung.Size = New System.Drawing.Size(254, 321)
        Me.txtNoiDung.TabIndex = 0
        '
        'lstList
        '
        Me.lstList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lstList.FormattingEnabled = True
        Me.lstList.Location = New System.Drawing.Point(3, 3)
        Me.lstList.Name = "lstList"
        Me.lstList.Size = New System.Drawing.Size(259, 351)
        Me.lstList.TabIndex = 1
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 3
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel3.Controls.Add(Me.butXoa, 2, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.butSua, 1, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.butThem, 0, 0)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(3, 360)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 1
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(259, 41)
        Me.TableLayoutPanel3.TabIndex = 2
        '
        'butXoa
        '
        Me.butXoa.Dock = System.Windows.Forms.DockStyle.Fill
        Me.butXoa.Location = New System.Drawing.Point(175, 3)
        Me.butXoa.Name = "butXoa"
        Me.butXoa.Size = New System.Drawing.Size(81, 35)
        Me.butXoa.TabIndex = 2
        Me.butXoa.Text = "Xoá"
        Me.butXoa.UseVisualStyleBackColor = True
        '
        'butSua
        '
        Me.butSua.Dock = System.Windows.Forms.DockStyle.Fill
        Me.butSua.Location = New System.Drawing.Point(89, 3)
        Me.butSua.Name = "butSua"
        Me.butSua.Size = New System.Drawing.Size(80, 35)
        Me.butSua.TabIndex = 1
        Me.butSua.Text = "Sửa"
        Me.butSua.UseVisualStyleBackColor = True
        '
        'butThem
        '
        Me.butThem.Dock = System.Windows.Forms.DockStyle.Fill
        Me.butThem.Location = New System.Drawing.Point(3, 3)
        Me.butThem.Name = "butThem"
        Me.butThem.Size = New System.Drawing.Size(80, 35)
        Me.butThem.TabIndex = 0
        Me.butThem.Text = "Thêm"
        Me.butThem.UseVisualStyleBackColor = True
        '
        'frmQuanLi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(531, 404)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.MaximizeBox = False
        Me.Name = "frmQuanLi"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Quản lí câu hỏi"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents lstList As System.Windows.Forms.ListBox
    Friend WithEvents txtNoiDung As System.Windows.Forms.TextBox
    Friend WithEvents txtTraLoi As System.Windows.Forms.TextBox
    Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents butThem As System.Windows.Forms.Button
    Friend WithEvents butXoa As System.Windows.Forms.Button
    Friend WithEvents butSua As System.Windows.Forms.Button
End Class
