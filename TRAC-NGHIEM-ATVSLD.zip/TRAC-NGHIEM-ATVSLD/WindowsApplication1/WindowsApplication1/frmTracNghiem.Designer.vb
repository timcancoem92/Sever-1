﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTracNghiem
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.rdb4 = New System.Windows.Forms.RadioButton()
        Me.rdb3 = New System.Windows.Forms.RadioButton()
        Me.rdb2 = New System.Windows.Forms.RadioButton()
        Me.txtCauHoi = New System.Windows.Forms.TextBox()
        Me.rdb1 = New System.Windows.Forms.RadioButton()
        Me.butTraLoi = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.rdb4, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.rdb3, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.rdb2, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.txtCauHoi, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.rdb1, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.butTraLoi, 0, 5)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 6
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(491, 326)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'rdb4
        '
        Me.rdb4.AutoSize = True
        Me.rdb4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.rdb4.Location = New System.Drawing.Point(3, 245)
        Me.rdb4.Name = "rdb4"
        Me.rdb4.Size = New System.Drawing.Size(485, 26)
        Me.rdb4.TabIndex = 4
        Me.rdb4.TabStop = True
        Me.rdb4.Text = "RadioButton1"
        Me.rdb4.UseVisualStyleBackColor = True
        '
        'rdb3
        '
        Me.rdb3.AutoSize = True
        Me.rdb3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.rdb3.Location = New System.Drawing.Point(3, 213)
        Me.rdb3.Name = "rdb3"
        Me.rdb3.Size = New System.Drawing.Size(485, 26)
        Me.rdb3.TabIndex = 3
        Me.rdb3.TabStop = True
        Me.rdb3.Text = "RadioButton1"
        Me.rdb3.UseVisualStyleBackColor = True
        '
        'rdb2
        '
        Me.rdb2.AutoSize = True
        Me.rdb2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.rdb2.Location = New System.Drawing.Point(3, 181)
        Me.rdb2.Name = "rdb2"
        Me.rdb2.Size = New System.Drawing.Size(485, 26)
        Me.rdb2.TabIndex = 2
        Me.rdb2.TabStop = True
        Me.rdb2.Text = "RadioButton1"
        Me.rdb2.UseVisualStyleBackColor = True
        '
        'txtCauHoi
        '
        Me.txtCauHoi.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtCauHoi.Location = New System.Drawing.Point(3, 3)
        Me.txtCauHoi.Multiline = True
        Me.txtCauHoi.Name = "txtCauHoi"
        Me.txtCauHoi.ReadOnly = True
        Me.txtCauHoi.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtCauHoi.Size = New System.Drawing.Size(485, 140)
        Me.txtCauHoi.TabIndex = 0
        '
        'rdb1
        '
        Me.rdb1.AutoSize = True
        Me.rdb1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.rdb1.Location = New System.Drawing.Point(3, 149)
        Me.rdb1.Name = "rdb1"
        Me.rdb1.Size = New System.Drawing.Size(485, 26)
        Me.rdb1.TabIndex = 1
        Me.rdb1.TabStop = True
        Me.rdb1.Text = "RadioButton1"
        Me.rdb1.UseVisualStyleBackColor = True
        '
        'butTraLoi
        '
        Me.butTraLoi.Dock = System.Windows.Forms.DockStyle.Fill
        Me.butTraLoi.Location = New System.Drawing.Point(3, 277)
        Me.butTraLoi.Name = "butTraLoi"
        Me.butTraLoi.Size = New System.Drawing.Size(485, 46)
        Me.butTraLoi.TabIndex = 5
        Me.butTraLoi.Text = "Trả lời"
        Me.butTraLoi.UseVisualStyleBackColor = True
        '
        'frmTracNghiem
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(491, 326)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmTracNghiem"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Trắc nghiệm"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents txtCauHoi As System.Windows.Forms.TextBox
    Friend WithEvents rdb1 As System.Windows.Forms.RadioButton
    Friend WithEvents rdb4 As System.Windows.Forms.RadioButton
    Friend WithEvents rdb3 As System.Windows.Forms.RadioButton
    Friend WithEvents rdb2 As System.Windows.Forms.RadioButton
    Friend WithEvents butTraLoi As System.Windows.Forms.Button
End Class
