﻿Imports System.IO
Imports System.Threading


Public Class frmPortal


    Private Sub butQuanLi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butQuanLi.Click
        If TextBox1.Text = "hungcoder.com" Then
            MsgBox("Bạn Được Quyền Truy Cập Vào Khu Vực QUản Lý Câu Hỏi", vbInformation, "Thông Báo")
            TextBox1.Enabled = False
            frmQuanLi.ShowDialog(Me)
        Else
            MsgBox("Bạn Chưa Nhập Đúng Mật Khẩu", vbExclamation, "Thông Báo")
        End If
    End Sub

    Private Sub butTracNghiem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butTracNghiem.Click
        frmTracNghiem.ShowDialog(Me)
    End Sub

End Class

