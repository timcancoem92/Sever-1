﻿Public Class Form1

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        SendKeys.Send(TextBox1.Text)
        SendKeys.Send("{Enter}")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ' Timer1.Interval = TextBox2.Text * 1000
        Timer1.Start()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Timer1.Stop()
    End Sub

    Private Sub HướngDẫnToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HướngDẫnToolStripMenuItem.Click
        MessageBox.Show("My Website : HungCoder.Com", "Thông Báo")
        Process.Start("https://link.hungcoder.com/go/trangchu")
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer2.Start()
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Try
            Label3.Text = My.Computer.Info.OSFullName
            Button1.Enabled = True
            Button2.Enabled = True
            Timer2.Stop()
            MessageBox.Show("Bạn Có Thể Sữ Dụng Tiện Ích Này", "Thông Báo")

        Catch ex As Exception

        End Try
     


    End Sub
End Class
