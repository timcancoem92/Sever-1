﻿Public Class Form1
    Dim webclient As New Net.WebClient
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        '  ListBox1.Items.Add(webclient.DownloadString("http://sever1.hungcoder.com/notice.txt"))
        '  TextBox2.Text = webclient.DownloadString("http://sever1.hungcoder.com/notice.txt")
        MsgBox("Chưa Phát Triển Đóng Góp Của Người Dùng", vbInformation, "Notice")
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox2.Text = webclient.DownloadString("http://sever1.hungcoder.com/tai-lieu-an-toan.txt")


        ' khởi động cùng windows
        My.Computer.Registry.CurrentUser.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", True).SetValue(Application.ProductName, Application.ExecutablePath)

        'update
        Dim request As System.Net.HttpWebRequest = System.Net.HttpWebRequest.Create("http://sever1.hungcoder.com/update-an-toan.txt")
        Dim response As System.Net.HttpWebResponse = request.GetResponse()

        Dim sr As System.IO.StreamReader = New System.IO.StreamReader(response.GetResponseStream())

        Dim newestversion As String = sr.ReadToEnd()
        Dim currentversion As String = Application.ProductVersion

        If newestversion.Contains(currentversion) Then
        Else
            MsgBox("Đã Có Bản Cập Nhật Mới Về An Toàn Điện", MsgBoxStyle.DefaultButton1, "Thông Báo")
            Process.Start("https://www.hungcoder.com/antoandien")
            End
        End If

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        WebBrowser1.Navigate("https://www.hungcoder.com/2019/07/vb-net-cach-tao-chuong-trinh-ban-quyen-trong-visual-basic.html")
    End Sub

    Private Sub Form1_FormClosed(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub
End Class
