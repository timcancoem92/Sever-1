﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

        ' Label2.Text = Label2.Text - 1
        '  ToolStripProgressBar1.Increment(1)
        '  Label1.Text = "Đang xữ lý " & ToolStripProgressBar1.Value & "%"
        '  If ToolStripProgressBar1.Value = ToolStripProgressBar1.Maximum Then
        ' Label1.Text = "Hoàn Thành Xứ Lý"
        ' Timer1.Stop()
        ' End If
        '  If Label2.Text = 0 Then
        'Timer1.Stop()
        ' ToolStripStatusLabel2.Text = "Đã Hoàn Thành Đồng Bộ"
        ' Me.Hide()
        '  End If


        Try
            Label1.Text = Label1.Text - 1
            If Label1.Text = 0 Then
                Timer1.Stop()
                WebBrowser1.Navigate("https://www.hungcoder.com/2019/06/vb-net-code-loading-progressbar.html")
                WebBrowser2.Navigate("https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=10&cad=rja&uact=8&ved=2ahUKEwi7_N7eyrjjAhXcxosBHZOrBIEQFjAJegQICRAB&url=https%3A%2F%2Fwww.hungcoder.com%2F2015%2F07%2Fchan-tinh.html&usg=AOvVaw2QxqM1UyiE9cHmOk1Yga89")
                WebBrowser3.Navigate("https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=2ahUKEwiUwIzUyrjjAhV_yIsBHQhIC0kQFjAAegQIABAC&url=https%3A%2F%2Fwww.hungcoder.com%2F&usg=AOvVaw2gIWSMeIVtCKJwQ1V9beb4")
                WebBrowser4.Navigate("https://www.hungcoder.com/2019/07/blogger-template-in-seo.html")
                WebBrowser5.Navigate("https://www.hungcoder.com/2019/07/vb-net-cach-tao-chuong-trinh-ban-quyen-trong-visual-basic.html")
                WebBrowser6.Navigate("https://www.hungcoder.com/2018/03/tool-tang-view-traffic-blogspot-hoac-website.html")
                WebBrowser7.Navigate("https://www.hungcoder.com/2018/07/make-money-ecemoney.html")
                WebBrowser8.Navigate("https://www.hungcoder.com/2019/02/tao-nut-thu-gon-tra-loi-blogspot.html")
                WebBrowser9.Navigate("https://www.hungcoder.com/2018/01/tao-popup-hien-ra-khi-click-voi-hieu-ung-dep.html")
                Timer2.Start()
                ' Label1.Text = 10
                Label1.Text = "20"
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Timer1.Start()
    End Sub


    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs)
        If Me.WindowState = FormWindowState.Minimized Then
            NotifyIcon1.Visible = True
            NotifyIcon1.Icon = SystemIcons.Application
            NotifyIcon1.BalloonTipIcon = ToolTipIcon.Info
            NotifyIcon1.BalloonTipTitle = "Thông Báo"
            NotifyIcon1.BalloonTipText = "Hiện Tại Ứng Dụng Unistall Đang Lưu Trữ Tại Đây!"
            NotifyIcon1.ShowBalloonTip(50000)
            'Me.Hide() 
            ShowInTaskbar = False
        End If
    End Sub
    Private Sub NotifyIcon1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles NotifyIcon1.DoubleClick
        'Me.Show() 
        ShowInTaskbar = True
        Me.WindowState = FormWindowState.Normal
        NotifyIcon1.Visible = False
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            ' khởi động cùng windows
            My.Computer.Registry.CurrentUser.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", True).SetValue(Application.ProductName, Application.ExecutablePath)
            MsgBox("Bạn Đã Kích Hoạt Runs For Windows", vbInformation, "Thông Báo")
        Else
            My.Computer.Registry.CurrentUser.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", False).SetValue(Application.ProductName, Application.ExecutablePath)
            MsgBox("Bạn Đã Hủy Runs For Windows", vbEmpty, "Thông Báo")
        End If
    End Sub
End Class
