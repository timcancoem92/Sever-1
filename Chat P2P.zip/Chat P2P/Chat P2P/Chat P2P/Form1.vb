﻿Imports System.Net.Sockets
Imports System.Threading
Imports System.IO
Public Class Form1
    Dim Listener As New TcpListener(65535)
    Dim Client As New TcpClient
    Dim Message As String = ""

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim ListThead As New Thread(New ThreadStart(AddressOf Listenning))
        Listener.Start()
    End Sub

    Private Sub Listenning()
        Listener.Start()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If Listener.Pending = True Then
            Message = ""
            Client = Listener.AcceptTcpClient()
            Dim Reader As New StreamReader(Client.GetStream)
            While Reader.Peek > -1
                Message = Message + Convert.ToChar(Reader.Read()).ToString

            End While
            RichTextBox1.AppendText(Message)
        End If
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Listener.Stop()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Client = New TcpClient(TextBox1.Text, 65535)
        Dim Writer As New StreamWriter(Client.GetStream)
        Dim tenmay As String = DateAndTime.Now.ToString & ":" & "@" & TextBox3.Text & ":" & " say: "
        Writer.Write(tenmay & TextBox2.Text + vbLf)
        Writer.Flush()

        TextBox3.Enabled = False
        TextBox1.Enabled = False
        TextBox2.Clear()
    End Sub
    ' Lấy tên của máy hiện tại phân giải từ IP
    Public Function GetComputerName()
        Dim computerName As String
        computerName = System.Net.Dns.GetHostName
        Return computerName
    End Function

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        ' TextBox1.Text = FormatDateTime.now.ToString
    End Sub
End Class
